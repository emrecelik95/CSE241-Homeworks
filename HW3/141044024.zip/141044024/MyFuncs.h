#ifndef MYFUNCS_H
#define MYFUNCS_H

using namespace std;
/* line icerisinde virgul var mı kontrol et                                   */
bool commaExist(string line);
/* verilen stringi integera çevirir                                           */
int myStrToInt(string strNum);
/* stringte eğer varsa küçük harfleri büyük harfe çevirir                     */
string lowToUp(string str);


#endif

